Sound files for each action should be in the following locations:

File Structure:

disk://01/001.wav = Startup
disk://02/001.wav = Fire
disk://03/001.wav = Reload
disk://04/001.wav = Out of Ammo

Files can be wav or mp3 (should be .mp3 files if mp3)